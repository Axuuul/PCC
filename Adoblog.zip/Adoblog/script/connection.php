<?php 
    $mysqli = new mysqli('localhost', 'root', '', 'adoblog') or die(mysqli_error($mysqli));
?>